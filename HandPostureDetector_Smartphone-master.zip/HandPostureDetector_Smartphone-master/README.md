# HandPostureDetector_Smartphone
A hand posture detector for smartphone
